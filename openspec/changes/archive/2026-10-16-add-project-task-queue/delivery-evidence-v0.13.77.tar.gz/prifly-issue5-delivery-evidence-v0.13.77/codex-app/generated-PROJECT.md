Do not recommend diagnostics by task; keep it selectable. Use descriptions, never ID words.
