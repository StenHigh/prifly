from pathlib import Path
import sys
source = Path(__file__).with_name('qualification.py').read_text()
exec(compile(source.split("if sys.argv[1] == 'prepare':")[0], 'qualification-shared', 'exec'))
phase = sys.argv[1]
assert phase in ['before-retry', 'after-retry']
first = json.loads((EVIDENCE / 'start-first.stdout').read_bytes())
run_id = first['run_id']
next_action = capture('next-' + phase, PREFIX + ['run', 'next', run_id, '--project', str(AUTHORITY), '--json'])
print(json.dumps({'next': next_action}))
queue = capture('queue-' + phase, PREFIX + ['project', 'queue', 'show', '--project', str(AUTHORITY), '--task-id', TASK, '--json'])
status = capture('status-' + phase, PREFIX + ['run', 'status', run_id, '--project', str(AUTHORITY), '--json'])
runs = capture('runs-' + phase, PREFIX + ['run', 'list', '--project', str(AUTHORITY), '--limit', '1000', '--json'])
run = status['run']
raw = base64.b64decode(run['queue_request_bytes'], validate=True)
assert raw == (EVIDENCE / 'original-task-input.json').read_bytes()
(EVIDENCE / ('sealed-original-task-input-' + phase + '.json')).write_bytes(raw)
(EVIDENCE / ('sealed-queue-request-bytes-' + phase + '.base64')).write_text(run['queue_request_bytes'])
(EVIDENCE / ('association-' + phase + '.json')).write_text(json.dumps(queue['task']['associations'], indent=2) + '\n')
print(json.dumps({'status': run['status'], 'outcome': run['outcome'], 'queue_state': queue['task']['state'], 'association_count': len(queue['task']['associations']), 'run_count': runs['total']}))
