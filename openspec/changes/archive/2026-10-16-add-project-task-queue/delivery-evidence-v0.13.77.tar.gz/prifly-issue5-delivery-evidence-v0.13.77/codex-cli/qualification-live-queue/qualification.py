import base64
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys

ROOT = Path('/tmp/prifly-issue5-live-codex-cli-v0.13.77')
EVIDENCE = ROOT / 'qualification-live-queue'
REPOSITORY = ROOT / 'project/repository'
AUTHORITY = ROOT / 'project/authority'
PREFIX = ['env', 'HOME=' + str(ROOT / 'home'), 'XDG_CONFIG_HOME=' + str(ROOT / 'home/.config'), '/tmp/prifly-release-v0.13.77-issue5/bin/prifly']
TASK = 'queue-task:5adff6d8ba1e7a3347dfa759c03d05c7a0ff5689a1b4909c0423417d91447aa5'
DIGEST = 'sha256:c659701749bd93a4af214204223f5b0741ac51571420bab7784ffe60dd37297f'
COMMON = ['--project', str(AUTHORITY), '--repository', str(REPOSITORY), '--launch', 'repair-fast', '--task-id', TASK, '--task-owner', 'session:live-queue', '--task-revision', '1', '--task-claim-generation', '1', '--decision-policy', 'attended', '--preflight-answer', 'output_mode="compact"', '--input', 'request=' + str(REPOSITORY / 'request.json'), '--expected-decision-catalog-digest', 'sha256:3a84f53d6bf5c2d9c3faaf4d2cff02448827e36a5173bc19cdb96481bbbba438']

def capture(name, argv):
    for suffix in ['argv.json', 'stdout', 'stderr', 'exit-code']:
        if (EVIDENCE / (name + '.' + suffix)).exists():
            raise RuntimeError('Evidence already exists: ' + name)
    (EVIDENCE / (name + '.argv.json')).write_text(json.dumps(argv, indent=2) + '\n')
    (EVIDENCE / (name + '.command.sh')).write_text(shlex.join(argv) + '\n')
    result = subprocess.run(argv, cwd=REPOSITORY, capture_output=True)
    (EVIDENCE / (name + '.stdout')).write_bytes(result.stdout)
    (EVIDENCE / (name + '.stderr')).write_bytes(result.stderr)
    (EVIDENCE / (name + '.exit-code')).write_text(str(result.returncode) + '\n')
    print(json.dumps({'evidence': name, 'exit_code': result.returncode}))
    if result.returncode:
        print(result.stdout.decode(), result.stderr.decode())
        raise SystemExit(result.returncode)
    return json.loads(result.stdout)

if sys.argv[1] == 'prepare':
    task = capture('queue-before', PREFIX + ['project', 'queue', 'show', '--project', str(AUTHORITY), '--task-id', TASK, '--json'])
    t = task['task']
    assert t['revision'] == 1 and t['claim']['owner'] == 'session:live-queue' and t['claim_generation'] == 1
    assert not t['intents'] and not t['associations']
    original = next(r for r in t['revisions'] if r['revision'] == 1)
    raw = base64.b64decode(original['request_bytes'], validate=True)
    assert 'sha256:' + hashlib.sha256(raw).hexdigest() == original['request_digest']
    (EVIDENCE / 'original-task-input.json').write_bytes(raw)
    (EVIDENCE / 'original-request-bytes.base64').write_text(original['request_bytes'])
    (EVIDENCE / 'original-raw-text.txt').write_text(json.loads(raw)['raw_text'])
    (EVIDENCE / 'typed-request.json').write_bytes((REPOSITORY / 'request.json').read_bytes())
    review = capture('review', PREFIX + ['project', 'questionnaire', '--prepare'] + COMMON + ['--json'])
    assert review['review_digest'] == DIGEST, 'Review changed; do not start'
    assert review['queue_task']['request_digest'] == original['request_digest']
    start = PREFIX + ['project', 'start'] + COMMON + ['--expected-launch-digest', DIGEST, '--command-id', 'live-queue-repair-fast-compact-20261016-01', '--json']
    (EVIDENCE / 'start.argv.json').write_text(json.dumps(start, indent=2) + '\n')
    (EVIDENCE / 'start.command.sh').write_text(shlex.join(start) + '\n')
    print(json.dumps({'review_digest': review['review_digest'], 'start_command_id': 'live-queue-repair-fast-compact-20261016-01', 'original_request_digest': original['request_digest']}))
elif sys.argv[1] in ['start', 'retry']:
    assert json.loads((EVIDENCE / 'review.stdout').read_text())['review_digest'] == DIGEST
    assert (REPOSITORY / 'request.json').read_bytes() == (EVIDENCE / 'typed-request.json').read_bytes(), 'Typed input changed'
    result = capture('start-first' if sys.argv[1] == 'start' else 'start-retry', json.loads((EVIDENCE / 'start.argv.json').read_text()))
    print(json.dumps({'run_id': result.get('run_id'), 'schema_version': result.get('schema_version')}))
else:
    raise SystemExit('Unknown action')
